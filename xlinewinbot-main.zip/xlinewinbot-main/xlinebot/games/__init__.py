"""Game routers and mechanics."""
